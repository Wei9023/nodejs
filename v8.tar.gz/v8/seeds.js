var mongoose = require("mongoose");
var Campground = require("./models/campground");
var Comment    = require("./models/comment")

var data = [
    {
        name:"Logan, United States" ,
        image: "https://images.unsplash.com/photo-1465800872432-a98681fc5828?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=8f3874f8c325f769c5b726960ca3f598&auto=format&fit=crop&w=896&q=80",
        description: "With frontage on the north shore Middle Thompson Lake, Logan is heavily forested western larch."
    },
    {
        name:"Niederbauen-Chulm, Emmetten, Switzerland",
        image: "https://images.unsplash.com/photo-1464547323744-4edd0cd0c746?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=a2f853d71f43de92c4d568531aa5608f&auto=format&fit=crop&w=1050&q=80",
        description: 
            "Hang-gliders know the Niederbauen mountain crest."
    },
    {
        name: "Arches National Park, Moab, United States",
        image: "https://images.unsplash.com/photo-1496545672447-f699b503d270?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=ba3fa37b995a705a01d022cada13f726&auto=format&fit=crop&w=1051&q=80",
        description: "Visit Arches to discover a landscape of contrasting colors, land forms and textures unlike any other in the world."
    }
    ];

function seedDB(){
    Campground.remove()};
    //remove all campgrounds
//   Campground.remove({}, function(err){
//         if(err){
//             console.log(err);
//         }else{
//             console.log("removed campgrounds");
//             data.forEach(function(seed){
//                 Campground.create(seed, function(err,  campground){
//                     if(err){
//                         console.log(err);
//                     }else{
//                         console.log("added a campground");
//                         //creat a comment
//                         Comment.create(
//                             {
//                                 text: "This place is great, but I wish there was internet",
//                                 author: "Homer"
//                             }, function(err, comment){
//                                 if(err){
//                                     console.log(err);
//                                 }else{
//                                     campground.comments.push(comment);
//                                     campground.save();
//                                     console.log("Created new comment");
//                                 }
//                             });
//                     }
//                 });
//             });
//         }
//     }); 
//     //add a few campgrounds
// }

module.exports = seedDB;